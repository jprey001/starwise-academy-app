'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { BookOpen, Play, Trophy, Users, Crown, Menu, Globe, Sun, Moon } from 'lucide-react'
import { LearningModule } from './components/learning-module'
import { PracticeQuiz } from './components/practice-quiz'
import { ProgressTracking } from './components/progress-tracking'
import { StudentEngagement } from './components/student-engagement'
import { SubscriptionTier } from './components/subscription-tier'
import { InAppPurchase } from './components/in-app-purchase'
import Logo from './components/Logo'

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('learn')
  const [subscriptionTier, setSubscriptionTier] = useState('free')
  const [contentType, setContentType] = useState('traditional')
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false)
  const [completedLessons, setCompletedLessons] = useState<string[]>([])
  const [quizScores, setQuizScores] = useState<{ [key: string]: number }>({})
  const [language, setLanguage] = useState('en')
  const [theme, setTheme] = useState('light')

  useEffect(() => {
    // Load user data from localStorage
    const savedSubscriptionTier = localStorage.getItem('subscriptionTier')
    const savedCompletedLessons = JSON.parse(localStorage.getItem('completedLessons') || '[]')
    const savedQuizScores = JSON.parse(localStorage.getItem('quizScores') || '{}')
    const savedLanguage = localStorage.getItem('language') || 'en'
    const savedTheme = localStorage.getItem('theme') || 'light'

    if (savedSubscriptionTier) setSubscriptionTier(savedSubscriptionTier)
    if (savedCompletedLessons) setCompletedLessons(savedCompletedLessons)
    if (savedQuizScores) setQuizScores(savedQuizScores)
    if (savedLanguage) setLanguage(savedLanguage)
    if (savedTheme) setTheme(savedTheme)
  }, [])

  useEffect(() => {
    // Save user data to localStorage
    localStorage.setItem('subscriptionTier', subscriptionTier)
    localStorage.setItem('completedLessons', JSON.stringify(completedLessons))
    localStorage.setItem('quizScores', JSON.stringify(quizScores))
    localStorage.setItem('language', language)
    localStorage.setItem('theme', theme)
    
    // Apply theme
    document.documentElement.classList.toggle('dark', theme === 'dark')
  }, [subscriptionTier, completedLessons, quizScores, language, theme])

  const handleUpgradeClick = () => {
    setShowSubscriptionDialog(true)
  }

  const handleLessonComplete = (lessonTitle: string) => {
    setCompletedLessons(prev => [...prev, lessonTitle])
  }

  const handleQuizComplete = (quizName: string, score: number) => {
    setQuizScores(prev => ({ ...prev, [quizName]: score }))
  }

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light')
  }

  const content = {
    en: {
      title: "WealthWise Academy: Your Financial Adventure Begins!",
      upgrade: "Level Up to Premium",
      contentType: "Choose Your Learning Style:",
      traditional: "Classic Quest",
      popCulture: "Pop Culture Challenge",
      learn: "Learn",
      practice: "Practice",
      progress: "Progress",
      engage: "Connect",
      privacyPolicy: "Privacy Shield",
      accessibility: "Accessibility for All",
    },
    es: {
      title: "Academia WealthWise: ¡Tu Aventura Financiera Comienza!",
      upgrade: "Sube de Nivel a Premium",
      contentType: "Elige Tu Estilo de Aprendizaje:",
      traditional: "Misión Clásica",
      popCulture: "Desafío de Cultura Pop",
      learn: "Aprender",
      practice: "Practicar",
      progress: "Progreso",
      engage: "Conectar",
      privacyPolicy: "Escudo de Privacidad",
      accessibility: "Accesibilidad para Todos",
    }
  }

  return (
    <div className={`max-w-6xl mx-auto p-4 ${theme === 'dark' ? 'bg-ww-gray text-white' : 'bg-gradient-to-br from-ww-blue via-ww-green to-ww-yellow bg-opacity-10'} min-h-screen`}>
      <header className="flex justify-between items-center mb-4">
        <Link href="/" aria-label="Home">
          <Logo className="w-16 h-16 cursor-pointer animate-bounce" theme={theme as 'light' | 'dark'} />
        </Link>
        <h1 className="text-2xl sm:text-3xl font-bold text-ww-blue dark:text-ww-green animate-pulse" tabIndex={0}>{content[language].title}</h1>
        {subscriptionTier === 'free' && (
          <Button 
            onClick={handleUpgradeClick}
            className="bg-gradient-to-r from-ww-yellow to-ww-orange text-ww-blue hover:from-ww-green hover:to-ww-blue hover:text-white transition-all duration-300"
          >
            <Crown className="h-5 w-5 mr-2" />
            {content[language].upgrade}
          </Button>
        )}
      </header>

      <nav className="flex flex-wrap items-center gap-4 mb-4">
        <span className="font-medium text-ww-purple">{content[language].contentType}</span>
        <Button
          variant={contentType === 'traditional' ? 'default' : 'outline'}
          onClick={() => setContentType('traditional')}
          className="bg-ww-blue text-white hover:bg-ww-green transition-colors duration-300"
        >
          {content[language].traditional}
        </Button>
        <Button
          variant={contentType === 'popCulture' ? 'default' : 'outline'}
          onClick={() => setContentType('popCulture')}
          className="bg-ww-yellow text-ww-blue hover:bg-ww-orange hover:text-white transition-colors duration-300"
        >
          {content[language].popCulture}
        </Button>
      </nav>

      <main>
        <Card className="mb-6 border-0 shadow-lg overflow-hidden">
          <CardHeader className={`${theme === 'dark' ? 'bg-ww-blue' : 'bg-gradient-to-r from-ww-blue to-ww-green'} text-white rounded-t-lg`}>
            <CardTitle className="text-2xl sm:text-3xl font-bold">{content[language].title}</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4">
                <TabsTrigger value="learn" className="text-lg py-3 data-[state=active]:bg-ww-blue data-[state=active]:text-white transition-colors duration-300">
                  <BookOpen className="mr-2 h-5 w-5" />
                  {content[language].learn}
                </TabsTrigger>
                <TabsTrigger value="practice" className="text-lg py-3 data-[state=active]:bg-ww-green data-[state=active]:text-white transition-colors duration-300">
                  <Play className="mr-2 h-5 w-5" />
                  {content[language].practice}
                </TabsTrigger>
                <TabsTrigger value="progress" className="text-lg py-3 data-[state=active]:bg-ww-yellow data-[state=active]:text-ww-blue transition-colors duration-300">
                  <Trophy className="mr-2 h-5 w-5" />
                  {content[language].progress}
                </TabsTrigger>
                <TabsTrigger value="engage" className="text-lg py-3 data-[state=active]:bg-ww-orange data-[state=active]:text-white transition-colors duration-300">
                  <Users className="mr-2 h-5 w-5" />
                  {content[language].engage}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="learn" className="p-4">
                <LearningModule 
                  subscriptionTier={subscriptionTier} 
                  contentType={contentType} 
                  completedLessons={completedLessons}
                  onLessonComplete={handleLessonComplete}
                  language={language}
                  theme={theme}
                />
              </TabsContent>

              <TabsContent value="practice" className="p-4">
                <PracticeQuiz 
                  subscriptionTier={subscriptionTier} 
                  contentType={contentType}
                  onQuizComplete={handleQuizComplete}
                  language={language}
                  theme={theme}
                />
              </TabsContent>

              <TabsContent value="progress" className="p-4">
                <ProgressTracking 
                  contentType={contentType} 
                  subscriptionTier={subscriptionTier}
                  completedLessons={completedLessons}
                  quizScores={quizScores}
                  language={language}
                  theme={theme}
                />
              </TabsContent>

              <TabsContent value="engage" className="p-4">
                <StudentEngagement 
                  contentType={contentType} 
                  subscriptionTier={subscriptionTier}
                  language={language}
                  theme={theme}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        <SubscriptionTier 
          currentTier={subscriptionTier} 
          onUpgrade={setSubscriptionTier} 
          showDialog={showSubscriptionDialog}
          setShowDialog={setShowSubscriptionDialog}
          language={language}
          theme={theme}
        />
        <InAppPurchase subscriptionTier={subscriptionTier} language={language} theme={theme} />
      </main>

      <footer className="mt-8 text-center">
        <Link href="/privacy-policy" className="text-ww-blue hover:text-ww-green dark:text-ww-green dark:hover:text-ww-yellow transition-colors duration-300">
          {content[language].privacyPolicy}
        </Link>
        {' | '}
        <Link href="/accessibility" className="text-ww-blue hover:text-ww-green dark:text-ww-green dark:hover:text-ww-yellow transition-colors duration-300">
          {content[language].accessibility}
        </Link>
      </footer>

      <div className="fixed bottom-4 right-4 flex space-x-2">
        <Button variant="outline" size="icon" onClick={() => setLanguage(language === 'en' ? 'es' : 'en')} aria-label="Toggle language" className="bg-ww-light-gray text-ww-blue hover:bg-ww-blue hover:text-white transition-colors duration-300">
          <Globe className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={toggleTheme} aria-label="Toggle theme" className="bg-ww-light-gray text-ww-blue hover:bg-ww-blue hover:text-white transition-colors duration-300">
          {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
        </Button>
        <Button variant="outline" size="icon" asChild className="bg-ww-light-gray text-ww-blue hover:bg-ww-blue hover:text-white transition-colors duration-300">
          <Link href="/menu" aria-label="Menu">
            <Menu className="h-4 w-4" />
          </Link>
        </Button>
      </div>
    </div>
  )
}

