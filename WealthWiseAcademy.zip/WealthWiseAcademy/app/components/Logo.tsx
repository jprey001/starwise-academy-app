import React from 'react'

const Logo: React.FC<{ className?: string; theme?: 'light' | 'dark' }> = ({ className = '', theme = 'light' }) => {
  const mainColor = theme === 'light' ? '#4A90E2' : '#6EB6FF'
  const accentColor1 = theme === 'light' ? '#50E3C2' : '#7FFFD4'
  const accentColor2 = theme === 'light' ? '#F5A623' : '#FFD180'
  const textColor = theme === 'light' ? '#4A4A4A' : '#F8F8F8'

  return (
    <svg className={className} width="200" height="200" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="logoTitle logoDesc">
      <title id="logoTitle">WealthWise Academy Logo</title>
      <desc id="logoDesc">A cheerful owl with a graduation cap, representing financial wisdom and education</desc>
      
      {/* Owl body */}
      <circle cx="100" cy="100" r="90" fill={mainColor} />
      
      {/* Owl eyes */}
      <circle cx="70" cy="90" r="25" fill="white" />
      <circle cx="130" cy="90" r="25" fill="white" />
      <circle cx="70" cy="90" r="15" fill={accentColor2} />
      <circle cx="130" cy="90" r="15" fill={accentColor2} />
      
      {/* Owl beak */}
      <path d="M95 115 Q100 125 105 115 Z" fill={accentColor2} />
      
      {/* Owl eyebrows (for happy expression) */}
      <path d="M55 70 Q70 60 85 70" stroke={textColor} strokeWidth="4" strokeLinecap="round" />
      <path d="M115 70 Q130 60 145 70" stroke={textColor} strokeWidth="4" strokeLinecap="round" />
      
      {/* Graduation cap */}
      <rect x="50" y="30" width="100" height="20" rx="10" fill={accentColor1} />
      <path d="M60 50 L100 30 L140 50 L100 70 Z" fill={accentColor1} />
      <rect x="95" y="70" width="10" height="30" fill={accentColor1} />
      <circle cx="100" cy="100" r="8" fill={accentColor1} />
      
      {/* Dollar sign */}
      <path d="M90 140 L110 140 M100 130 L100 150" stroke={textColor} strokeWidth="6" strokeLinecap="round" />
      
      {/* Smile */}
      <path d="M70 130 Q100 150 130 130" stroke={textColor} strokeWidth="4" strokeLinecap="round" fill="none" />
    </svg>
  )
}

export default Logo

