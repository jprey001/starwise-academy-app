import Link from 'next/link'
import { Button } from "@/components/ui/button"
import Logo from './components/Logo'
import { useState } from 'react'

export default function LandingPage() {
  const [language, setLanguage] = useState('en')

  const content = {
    en: {
      title: "WealthWise Academy",
      subtitle: "Your Fun Path to Financial Freedom!",
      description: "Join thousands of teens mastering money skills through exciting games, quizzes, and real-life challenges!",
      cta: "Start Your Free Adventure",
      features: [
        "Personalized money quests",
        "Cool rewards and badges",
        "Fun challenges with friends",
        "Easy-to-understand lessons",
        "Mobile app for learning on-the-go"
      ],
      languageSelector: "Choose Your Language",
    },
    es: {
      title: "Academia WealthWise",
      subtitle: "¡Tu Camino Divertido hacia la Libertad Financiera!",
      description: "¡Únete a miles de adolescentes que dominan habilidades financieras a través de emocionantes juegos, cuestionarios y desafíos de la vida real!",
      cta: "Comienza Tu Aventura Gratis",
      features: [
        "Misiones de dinero personalizadas",
        "Geniales recompensas e insignias",
        "Desafíos divertidos con amigos",
        "Lecciones fáciles de entender",
        "App móvil para aprender en cualquier lugar"
      ],
      languageSelector: "Elige Tu Idioma",
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-ww-blue via-ww-green to-ww-yellow p-4">
      <div className="text-center bg-white bg-opacity-90 backdrop-filter backdrop-blur-lg rounded-xl p-8 shadow-2xl max-w-4xl w-full">
        <Logo className="mx-auto mb-8 w-40 h-40 animate-bounce" theme="light" />
        <h1 className="text-5xl sm:text-6xl font-bold text-ww-blue mb-4 animate-pulse" tabIndex={0}>{content[language].title}</h1>
        <h2 className="text-3xl text-ww-orange mb-4" tabIndex={0}>{content[language].subtitle}</h2>
        <p className="text-xl text-ww-gray mb-8" tabIndex={0}>{content[language].description}</p>
        <Link href="/dashboard" passHref>
          <Button className="bg-ww-yellow text-ww-blue hover:bg-ww-green hover:text-white font-bold py-3 px-6 rounded-full text-lg transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-ww-blue animate-pulse">
            {content[language].cta}
          </Button>
        </Link>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {content[language].features.map((feature, index) => (
            <div key={index} className="flex items-center bg-ww-light-gray p-4 rounded-lg shadow-md transition-transform transform hover:scale-105">
              <svg className="h-8 w-8 text-ww-purple mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-ww-gray font-medium">{feature}</span>
            </div>
          ))}
        </div>
        <div className="mt-8">
          <label htmlFor="language-select" className="sr-only">{content[language].languageSelector}</label>
          <select
            id="language-select"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-ww-light-gray text-ww-blue border-2 border-ww-blue rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-ww-green transition-colors"
          >
            <option value="en">English</option>
            <option value="es">Español</option>
          </select>
        </div>
      </div>
    </div>
  )
}

